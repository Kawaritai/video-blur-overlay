# Video Blur Overlay
**Description**: Add resizable blur overlays to YouTube and Twitch videos

This code was generated entirely by Claude 3.5 Sonnet with no manual alterations. 

It took only 6 (!) iterations to squash out the bugs to a satisfactory level.

![Demonstration of extension](example.png)